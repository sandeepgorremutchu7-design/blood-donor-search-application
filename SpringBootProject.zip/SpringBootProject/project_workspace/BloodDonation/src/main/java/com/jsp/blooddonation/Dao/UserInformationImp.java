package com.jsp.blooddonation.Dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jsp.blooddonation.entity.UserInformation;
import com.jsp.blooddonation.repository.UserRepository;

@Component
public class UserInformationImp implements UserInformationDao {

	@Autowired
	UserRepository userRepository;

	public UserInformation userRegistration(UserInformation userInformation) {

		UserInformation information = userRepository.save(userInformation);

		return information;
	}

	@Override
	public UserInformation userLogin(String emailid, String password) {

		return userRepository.findByEmailidAndPassword(emailid, password);
	}

	@Override
	public UserInformation findByEmailid(String emailid) {

		return userRepository.findByEmailid("dinga@gmail.com");
	}

	@Override
	public void updatePassword(String emailid, String password) {
		UserInformation information = userRepository.findByEmailid(emailid);
		if (information != null) {
			information.setPassword(password);
			UserInformation save = userRepository.save(information);
			System.out.println("password updated");
		} else {
			System.out.println("invalid password");
		}

	}

	@Override
	public Optional<UserInformation> findById(int id) {

		Optional<UserInformation> userInformation = userRepository.findById(id);
		if(userInformation!=null)
		{
			System.out.println(userInformation);
		}
		else {
			System.out.println("Invalid id");
		}
		return userInformation;
	}

}
