package com.jsp.blooddonation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.jsp.blooddonation.Dao.BloodDonorCenterDao;
import com.jsp.blooddonation.Dao.DonorDao;
import com.jsp.blooddonation.Dao.UserInformationDao;
import com.jsp.blooddonation.entity.BloodDonorCenter;
import com.jsp.blooddonation.entity.Donor;
import com.jsp.blooddonation.entity.UserInformation;

@SpringBootApplication
public class BloodDonationApplication implements CommandLineRunner {

	@Autowired
	UserInformationDao userInformationDao;

	@Autowired
	DonorDao donorDao;

	@Autowired
	BloodDonorCenterDao bloodDonorCenterDao;

	public static void main(String[] args) {
		SpringApplication.run(BloodDonationApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception 
	{
		
		//Insert data into user information
//		UserInformation userInformation= UserInformation.builder()
//				.address("kukatpally")
//				.firstname("Anil").lastname("Reddy").age(22).gender("Male")
//				.mobilenumber("6302987789").emailid("Anil@gmail.com")
//				.password("1431789").build();
//		System.out.println(userInformationDao.userRegistration(userInformation));
		
		
		//Insert data into Donor
//		Donor donor = Donor.builder().name("Anil").bloodgroup("a+")
//				.emailid("Anil@gmail.com").gender("male").healthcondition("normal")
//				.mobilennumber("6578989219").location("JNTU").build();
//		System.out.println(donorDao.donorRegistration(donor));

		
		//Insert data into Bood donor Center
//		BloodDonorCenter bloodDonorCenter = BloodDonorCenter.builder().centername("JNTU blood center")
//				.location("JNTU").centerphonenumber("7893065890").build();
//		System.out.println(bloodDonorCenterDao.donorCenterRegistration(bloodDonorCenter));

		//TO update user password
		 //userInformationDao.updatePassword("Anil@gmail.com", "987790");
		
		//donorDao.donorSearch("JNTU", "a+");
		//userInformationDao.findById(1);
	}
	
}
