package com.jsp.blooddonation.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jsp.blooddonation.entity.Donor;
import com.jsp.blooddonation.repository.DonorRepository;

@Component
public class DonorDaoImpl implements DonorDao {

	@Autowired
	DonorRepository donorRepository;

	@Override
	public Donor donorRegistration(Donor donor) {

		return donorRepository.save(donor);

	}

	@Override
	public java.util.List<Donor> donorSearch(String location, String bloodgroup) {
		java.util.List<Donor> donorAvailability = donorRepository.findByAddressAndBloodgroup(location, bloodgroup);
		if (donorAvailability != null) {
			for (Donor donor : donorAvailability) {
				System.out.println(donor);
			}
		} else {
			System.out.println("Donor not Available at your location");
		}
		return donorAvailability;

	}

}
