package com.jsp.blooddonation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.blooddonation.entity.BloodDonorCenter;

public interface BloodDonorCenterRepository extends JpaRepository<BloodDonorCenter, Integer> {

}
