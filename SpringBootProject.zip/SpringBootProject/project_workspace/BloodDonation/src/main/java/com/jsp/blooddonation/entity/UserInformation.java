package com.jsp.blooddonation.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Builder
public class UserInformation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(name = "First_name")
	private String firstname;
	@Column(name = "Last_Name")
	private String lastname;
	private int age;
	private String gender;
	@Column(unique = true, name = "Email_Id")
	private String emailid;
	@Column(nullable = false, name = "Mobile_Number", length = 10)
	private String mobilenumber;
	private String address;
	private String password;
}