package com.jsp.blooddonation.Dao;

import com.jsp.blooddonation.entity.BloodDonorCenter;

public interface BloodDonorCenterDao {

	public BloodDonorCenter donorCenterRegistration(BloodDonorCenter bloodDonorCenter);
	
}
