package com.jsp.blooddonation.Dao;

import java.util.Optional;

import com.jsp.blooddonation.entity.UserInformation;

public interface UserInformationDao {

	public UserInformation userRegistration(UserInformation userInformation);
	
	public UserInformation userLogin(String emailid,String password);
	UserInformation findByEmailid(String emailid);
	public void updatePassword(String emailid, String password);
	
	public Optional<UserInformation> findById(int id);
	
	
}
