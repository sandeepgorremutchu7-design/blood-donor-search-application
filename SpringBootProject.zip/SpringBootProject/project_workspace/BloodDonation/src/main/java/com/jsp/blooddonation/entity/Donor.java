package com.jsp.blooddonation.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
@Entity
@Builder
public class Donor 
{
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(nullable = false)
	private String firstname;
	@Column(nullable = false)
	private String gender;
	@Column(nullable = false, unique = true)
	private String emailid;
	@Column(nullable = false)
	private String address;
	@Column(nullable = false)
	private String healthcondition;
	@Column(nullable = false, length = 10)
	private String mobilenumber;
	@Column(nullable = false)
	private String bloodgroup;
	
}
