package com.jsp.blooddonation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.blooddonation.entity.UserInformation;

public interface UserRepository extends JpaRepository<UserInformation,Integer>
{
	UserInformation findByEmailidAndPassword(String Emailid, String password);
	UserInformation findByEmailid(String emailid);
}