package com.jsp.blooddonation.Dao;

import java.util.List;

import com.jsp.blooddonation.entity.Donor;

public interface DonorDao 
{
	public Donor donorRegistration(Donor donor);
	public List<Donor> donorSearch(String location, String bloodgroup);
}
