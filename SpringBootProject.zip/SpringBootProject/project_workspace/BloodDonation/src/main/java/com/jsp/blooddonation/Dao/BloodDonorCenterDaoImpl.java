package com.jsp.blooddonation.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jsp.blooddonation.entity.BloodDonorCenter;
import com.jsp.blooddonation.repository.BloodDonorCenterRepository;
@Component
public class BloodDonorCenterDaoImpl implements BloodDonorCenterDao{
	
	@Autowired
	BloodDonorCenterRepository bloodDonorCenterRepository;

	public BloodDonorCenter donorCenterRegistration(BloodDonorCenter bloodDonorCenter) {
		
		return bloodDonorCenterRepository.save(bloodDonorCenter) ;
	}

	
	

}
