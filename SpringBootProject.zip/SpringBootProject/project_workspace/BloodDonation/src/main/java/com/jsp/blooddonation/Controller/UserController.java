package com.jsp.blooddonation.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.jsp.blooddonation.Dao.UserInformationDao;
import com.jsp.blooddonation.entity.UserInformation;
import com.jsp.blooddonation.repository.UserRepository;

@Controller
public class UserController {
	@Autowired
	UserInformationDao userInformationDao;

	@Autowired
	UserRepository userRepository;

	@PostMapping("/userdetails")
	@ResponseBody
	public String insertdata(UserInformation information) {

		UserInformation information2 = userInformationDao.userRegistration(information);
		System.out.println(information2);
		return "Regisration successfull";
	}

	@GetMapping("/userlogin/{email},{password}")
	public String login(@RequestParam("email") String emailid, @RequestParam String password, Model model) {
		System.out.println(emailid);
//		UserInformation userRegistartion = userInformationDao.userLogin(emailid, password);
//		System.out.println(userRegistartion);
		try {
			UserInformation userInformation = userInformationDao.userLogin(emailid, password);
			model.addAttribute("user", userInformation.getId());
			return "SelectOperation";
		} catch (Exception e) {

			return "UserLogin";
		}

	}

	@PutMapping("/updatepassword/{emailid},{password}")
	public void updateUser(@PathVariable String emailid, @PathVariable String password) {

		UserInformation information = userRepository.findByEmailid(emailid);
		if (information != null) {
			information.setPassword(password);

			UserInformation save = userRepository.save(information);
			System.out.println("password updated");
		}

		else {
			System.out.println("invalid password");
		}
	}

	@RequestMapping(path = "/getRegistrationPage")
	public String userRegistrationPage(Model model) {
		UserInformation information = new UserInformation();
		model.addAttribute("information", information);
		return "UserRegistration";

	}

	@RequestMapping("/UserLoginPage")
	public String userLoginPage() {
		return "UserLogin";
	}

	@RequestMapping("/getuser/{id}")
	public String getUserDetails(@PathVariable Integer id, Model model) {
		System.out.println(id);
		UserInformation userInformation = userRepository.findById(id).get();
		model.addAttribute("user", userInformation);
		return"DonorRegistrationPage";
	}
}
