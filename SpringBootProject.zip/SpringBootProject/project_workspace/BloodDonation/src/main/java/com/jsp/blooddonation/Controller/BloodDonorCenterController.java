package com.jsp.blooddonation.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jsp.blooddonation.Dao.BloodDonorCenterDao;
import com.jsp.blooddonation.repository.BloodDonorCenterRepository;
import com.jsp.blooddonation.repository.DonorRepository;

@Controller
public class BloodDonorCenterController {

	@Autowired
	BloodDonorCenterDao bloodDonorCenterDao;
	
	@Autowired
	BloodDonorCenterRepository bloodDonorCenterRepository;
	
	@Autowired
	DonorRepository donorRepository;
	
	@RequestMapping("/getdonordetails/{address}/{bloodgroup}")
	public void getDonorDetails(String address,String bloodgroup)
	{
		donorRepository.findByAddressAndBloodgroup(address, bloodgroup);
		
	}

}
